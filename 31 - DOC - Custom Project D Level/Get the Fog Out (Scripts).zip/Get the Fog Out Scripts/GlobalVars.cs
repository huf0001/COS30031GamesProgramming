﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GlobalVars
{
    public static bool SkipTut { get; set; }
    public static int Difficulty { get; set; }
    public static bool LoadedFromMenu { get; set; }
}
