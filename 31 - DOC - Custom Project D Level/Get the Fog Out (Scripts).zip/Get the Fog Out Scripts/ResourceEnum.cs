﻿public enum Resource
{
    None,
    Power,
    Organic,
    Mineral,
    Fuel
}
