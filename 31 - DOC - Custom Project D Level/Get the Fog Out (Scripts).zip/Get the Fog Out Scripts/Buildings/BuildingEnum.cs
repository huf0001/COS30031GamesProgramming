﻿public enum BuildingType
{
    None,
    AirCannon,
    Battery,
    Generator,
    Harvester,
    Hub,
    Extender,
    FogRepeller
}
