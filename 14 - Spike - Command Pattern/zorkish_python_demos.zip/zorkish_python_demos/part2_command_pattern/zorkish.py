

if __name__ == '__main__':

    from adventure import Adventure
    adv = Adventure()
    adv.load('testworld.txt')
    adv.play()
    